/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.model;

import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

public class MessageModel {
    public static final int TYPE_TEXT = 0;
    public static final int TYPE_PHOTO = 1;

    public int type;
    public long time;
    public String message;
    public String photoFileUrl;
    public String otherUserPhoneNumber;
    public String senderUserPhoneNumber;
    public boolean isOwnMessage;

    public String toJsonString() {
        JSONObject jsonObject= new JSONObject();
        try {
            jsonObject.put("type", type);
            jsonObject.put("time", time);
            jsonObject.put("message", message);
            jsonObject.put("otherUserPhoneNumber", otherUserPhoneNumber);
            jsonObject.put("senderUserPhoneNumber", senderUserPhoneNumber);
            jsonObject.put("isOwnMessage", isOwnMessage);
            if (!TextUtils.isEmpty(photoFileUrl))
                jsonObject.put("photoFileUrl", photoFileUrl);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonObject.toString();
    }

    public static MessageModel getMessageModelFromJsonStr(String strJson) {
        try {
            JSONObject jsonObject= new JSONObject(strJson);
            MessageModel messageModel = new MessageModel();
            messageModel.type = jsonObject.getInt("type");
            messageModel.time = jsonObject.getLong("time");
            messageModel.message = jsonObject.getString("message");
            messageModel.otherUserPhoneNumber = jsonObject.getString("otherUserPhoneNumber");
            messageModel.isOwnMessage = jsonObject.getBoolean("isOwnMessage");
            if (jsonObject.has("photoFileUrl"))
                messageModel.photoFileUrl = jsonObject.getString("photoFileUrl");
            if (jsonObject.has("senderUserPhoneNumber"))
                messageModel.senderUserPhoneNumber = jsonObject.getString("senderUserPhoneNumber");
            else {
                messageModel.senderUserPhoneNumber = messageModel.otherUserPhoneNumber;
            }
            return messageModel;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
}
