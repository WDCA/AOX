/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.ao.aoxapp.AppConstant;
import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.http.TwilioApi;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.MessageModel;
import com.ao.aoxapp.model.NotificationModel;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.utility.CommonUtil;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.ao.aoxapp.utility.MyImageLoader;
import com.ao.aoxapp.utility.PermissionUtils;
import com.ao.aoxapp.utility.ResourceUtil;
import com.ao.aoxapp.utility.filechooser.Content;
import com.ao.aoxapp.utility.filechooser.Error;
import com.ao.aoxapp.utility.filechooser.FileChooser;
import com.ao.aoxapp.utility.filechooser.FileType;
import com.ao.aoxapp.utility.filechooser.OnContentSelectedListener;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.ao.aoxapp.utility.MyImageLoader.TYPE_NORMAL;

public class MessageActivity extends BaseActivity implements OnContentSelectedListener {
    private static final String TAG = "MessageActivity";

    public static MessageActivity instance;

    private static final String TWILIO_SERVER_URL = "https://aox.jimb.tk/sendMessage.php";
    private static final String FACEBOOK_CHANEL_ID = "102012727868625";
    private static final String LINE_CHANEL_ID = "1616665494";
    public static UserModel otherUser;

    @BindView(R.id.txt_message)
    EditText txt_message;
    @BindView(R.id.lbl_title)
    TextView lbl_title;
    @BindView(R.id.img_photo)
    CircleImageView img_photo;
    @BindView(R.id.loadingBar)
    ProgressBar loadingBar;

    @BindView(R.id.chatLst)
    LinearLayout chatLst;
    @BindView(R.id.chatScroll)
    ScrollView chatScroll;

    private FileChooser fileChooser;
    private Bitmap sendImageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        ButterKnife.bind(this);
        instance = this;
    }

    @Override
    public void onResume() {
        super.onResume();

        fileChooser = new FileChooser(this);

        if (otherUser == null) {
            onBack();
            return;
        }

        init();
    }

    @Override
    protected void onPause() {
        CommonUtil.hideKeyboard(instance, txt_message);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        onBack();
    }

    @OnClick(R.id.btn_back)
    public void onBack() {
        CommonUtil.hideKeyboard(instance, txt_message);
        finish();
        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
    }

    @OnClick(R.id.btn_send)
    public void onSend() {
        CommonUtil.hideKeyboard(this, txt_message);

        if (!DeviceUtil.isNetworkAvailable(this)) {
            return;
        }
        if (!txt_message.getText().toString().trim().isEmpty()) {
            makeMessage(MessageModel.TYPE_TEXT);
        } else {
            txt_message.setText("");
        }
    }

    @OnClick(R.id.btn_audioCall)
    public void onAudioCall() {
        Intent intent = new Intent(this, VoiceActivity.class);
        intent.putExtra(AppConstant.EK_USER_PHONENUMBER, otherUser.phoneNumber);
        startActivity(intent);
        overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
    }

    @OnClick(R.id.btn_videoCall)
    public void onVideoCall() {
        String roomName =  UserModel.currentUser.phoneNumber + otherUser.phoneNumber;

        Intent intent = new Intent(this, VideoCallActivity.class);
        intent.putExtra(AppConstant.EK_ROOMNAME, roomName);
        intent.putExtra(AppConstant.EK_USER_PHONENUMBER, otherUser.phoneNumber);
        startActivity(intent);
        overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);

        NotificationModel.sendVideoAudioCallNotification(otherUser, true, roomName);
    }

    @OnClick(R.id.btn_ai)
    public void onAI() {
        Intent intent = new Intent(this, AIActivity.class);
        intent.putExtra(AppConstant.EK_USER_PHONENUMBER, otherUser.phoneNumber);
        startActivity(intent);
        overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
    }

    @OnClick(R.id.btn_menu)
    public void onCamera() {
//        CommonUtil.hideKeyboard(this, txt_message);
//        showPhotoDialog();
    }

    private void showPhotoDialog() {
        new AlertDialog.Builder(instance)
                .setTitle(R.string.upload_photo)
                .setPositiveButton(R.string.select_gallery, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (PermissionUtils.checkPermissionForExternalStorage(instance)) {
                            chooseTakePhoto(false);
                        } else {
                            PermissionUtils.requestPermissionForExternalStorage(instance);
//                            MessageUtil.showError(instance, R.string.msg_error_permission_storage);
                        }
                    }
                })
                .setNegativeButton(R.string.take_new_photo, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (PermissionUtils.checkPermissionForCamera(instance)) {
                            if (PermissionUtils.checkPermissionForExternalStorage(instance)) {
                                chooseTakePhoto(true);
                            } else {
                                PermissionUtils.requestPermissionForExternalStorage(instance);
//                                MessageUtil.showError(instance, R.string.msg_error_permission_storage);
                            }
                        } else {
                            PermissionUtils.requestPermissionForCamera(instance);
//                            MessageUtil.showError(instance, R.string.msg_error_permission_camera);
                        }
                    }
                })
                .show();
    }

    private void chooseTakePhoto(boolean isTake) {
        if (!isTake) {
            fileChooser.getImage(this, true);
        } else {
            fileChooser.takePhoto(this);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (fileChooser != null)
            fileChooser.onActivityResult(requestCode, resultCode, data);
        else {
            fileChooser = new FileChooser(this);

            MessageUtil.showError(this, R.string.permission_changed);
            return;
        }
    }

    private void init() {
        if (UserModel.currentUser == null || UserModel.currentUser.phoneNumber == null) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
            finish();
            return;
        }

        lbl_title.setText(otherUser.phoneNumber);

        String thumbnail = otherUser.avatarURL;
        if (thumbnail != null && !thumbnail.isEmpty()) {
            loadingBar.setVisibility(View.VISIBLE);
            MyImageLoader.showAvatar(img_photo, thumbnail, TYPE_NORMAL, new SimpleImageLoadingListener() {
                public void onLoadingStarted(String imageUri, View view) {}
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { loadingBar.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { loadingBar.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { loadingBar.setVisibility(View.GONE); }
            });
        } else {
            img_photo.setImageResource(R.drawable.ic_default_user_avatar_green);
            loadingBar.setVisibility(View.GONE);
        }

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER);
        ref.addChildEventListener(mUsersChildEventListener);

        refresh();
    }

    ChildEventListener mUsersChildEventListener = new ChildEventListener() {
        @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {}
        @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                if (userModel.phoneNumber.equals(otherUser.phoneNumber)) {
                    otherUser = userModel;
                }
            } catch (Exception e) {}
        }
        @Override public void onChildRemoved(DataSnapshot dataSnapshot) {}
        @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
        @Override public void onCancelled(DatabaseError databaseError) {}
    };

    private void addSenderMessageToScreen(final MessageModel messageModel) {
        View sender = this.getLayoutInflater().inflate(R.layout.cell_sender, null);
        RelativeLayout layout_text = sender.findViewById(R.id.layout_text);
        RelativeLayout showPhoto = sender.findViewById(R.id.showPhoto);
        TextView messageContent = sender.findViewById(R.id.messageContent);
        TextView txt_time = sender.findViewById(R.id.txt_time);
        final ImageView img_postedImg = sender.findViewById(R.id.img_postedImg);
        TextView txt_time_photo = sender.findViewById(R.id.txt_time_photo);
        final ProgressBar loadingBar_image = sender.findViewById(R.id.loadingBar);
        final ImageView img_play = sender.findViewById(R.id.img_play);

        if (messageModel.type == MessageModel.TYPE_TEXT) {
            layout_text.setVisibility(View.VISIBLE);
            showPhoto.setVisibility(View.GONE);
            messageContent.setText(messageModel.message);
        } else {
            layout_text.setVisibility(View.GONE);
            showPhoto.setVisibility(View.VISIBLE);
            loadingBar_image.setVisibility(View.VISIBLE);

            MyImageLoader.showImage(img_postedImg, messageModel.photoFileUrl, new SimpleImageLoadingListener(){
                public void onLoadingStarted(String imageUri, View view) {}
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { loadingBar_image.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { loadingBar_image.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { loadingBar_image.setVisibility(View.GONE); }
            });
        }

        Date date = new Date(messageModel.time);
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");
        txt_time.setText(dateFormat.format(date));
        txt_time_photo.setText(dateFormat.format(date));

        chatLst.addView(sender);
        chatScroll.post(new TimerTask() {
            @Override
            public void run() {
                chatScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private void addReceiveMessageToScreen(final MessageModel messageModel) {
        View sender = this.getLayoutInflater().inflate(R.layout.cell_receiver, null);
        ImageView img_photo = sender.findViewById(R.id.img_photo);
        RelativeLayout layout_text = sender.findViewById(R.id.layout_text);
        RelativeLayout showPhoto = sender.findViewById(R.id.showPhoto);
        TextView messageContent = sender.findViewById(R.id.messageContent);
        final ImageView img_postedImg = sender.findViewById(R.id.img_postedImg);
        TextView txt_time = sender.findViewById(R.id.txt_time);
        TextView txt_time_photo = sender.findViewById(R.id.txt_time_photo);
        final ProgressBar loadingBar_image = sender.findViewById(R.id.loadingBar_image);
        final ProgressBar loadingBar_avatar = sender.findViewById(R.id.loadingBar_avatar);
        final ImageView img_play = sender.findViewById(R.id.img_play);

        if (!TextUtils.isEmpty(otherUser.avatarURL)) {
            loadingBar_avatar.setVisibility(View.VISIBLE);
            MyImageLoader.showAvatar(img_photo, otherUser.avatarURL, TYPE_NORMAL, new SimpleImageLoadingListener() {
                public void onLoadingStarted(String imageUri, View view) {}
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { loadingBar_avatar.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { loadingBar_avatar.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { loadingBar_avatar.setVisibility(View.GONE); }
            });
        } else {
            loadingBar_avatar.setVisibility(View.GONE);
        }

        if (messageModel.type == MessageModel.TYPE_TEXT) {
            layout_text.setVisibility(View.VISIBLE);
            showPhoto.setVisibility(View.GONE);
            messageContent.setText(messageModel.message);
        } else {
            layout_text.setVisibility(View.GONE);
            showPhoto.setVisibility(View.VISIBLE);
            loadingBar_image.setVisibility(View.VISIBLE);

            img_play.setVisibility(View.GONE);
            MyImageLoader.showImage(img_postedImg, messageModel.photoFileUrl, new SimpleImageLoadingListener() {
                public void onLoadingStarted(String imageUri, View view) {}
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) { loadingBar_image.setVisibility(View.GONE); }
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) { loadingBar_image.setVisibility(View.GONE); }
                public void onLoadingCancelled(String imageUri, View view) { loadingBar_image.setVisibility(View.GONE); }
            });
        }

        Date date = new Date(messageModel.time);
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");
        txt_time.setText(dateFormat.format(date));
        txt_time_photo.setText(dateFormat.format(date));

        chatLst.addView(sender);
        chatScroll.post(new TimerTask() {
            @Override
            public void run() {
                chatScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private void addMessageOnScreen(MessageModel messageModel) {
        if (messageModel.isOwnMessage) {
            addSenderMessageToScreen(messageModel);
        } else {
            addReceiveMessageToScreen(messageModel);
        }
    }

    private void uploadPhoto(final MessageModel messageModel) {
        if (sendImageBitmap != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            sendImageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();

            FirebaseStorage storage = FirebaseStorage.getInstance();
            String key = String.valueOf((new Date()).getTime());
            final StorageReference storageReference = storage.getReference().child(FirebaseConst.STORAGE_MESSAGE).child(key);
            UploadTask uploadTask = storageReference.putBytes(data);
            showProgressDialog();
            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    return storageReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    hidProgressDialog();
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        messageModel.photoFileUrl = downloadUri.toString();
                        sendMessage(messageModel);
                    } else {
                        MessageUtil.showError(instance, R.string.msg_error_network);
                    }
                }
            });
        }
    }

    private void makeMessage(final int type) {
        MessageModel messageModel = new MessageModel();
        messageModel.type = type;
        messageModel.time = new Date().getTime();
        messageModel.message = txt_message.getText().toString().trim();
        messageModel.otherUserPhoneNumber = otherUser.phoneNumber;
        messageModel.senderUserPhoneNumber = UserModel.currentUser.phoneNumber;
        messageModel.isOwnMessage = true;
        messageModel.photoFileUrl= "";

        txt_message.setText("");

        if (type == MessageModel.TYPE_PHOTO) {
            uploadPhoto(messageModel);
        } else {
            sendMessage(messageModel);
        }
    }

    private void sendMessage(final MessageModel messageModel) {
        String base64EncodedCredentials = "Basic " + Base64.encodeToString((AppConstant.TWILLIO_ACCOUNT_SID + ":" + AppConstant.TWILLIO_AUTH_TOKEN).getBytes(), Base64.NO_WRAP);
        Map<String, String> smsData = new HashMap<>();
        smsData.put("From", AppConstant.TWILLIO_PHONENUMBER);
        smsData.put("To", otherUser.phoneNumber);
        smsData.put("Body", messageModel.message);
        if (messageModel.type == MessageModel.TYPE_PHOTO) {
            smsData.put("MediaUrl", messageModel.photoFileUrl);
        }

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.twilio.com/2010-04-01/")
                .build();
        TwilioApi api = retrofit.create(TwilioApi.class);

        showProgressDialog();
        api.sendSMSMessage(AppConstant.TWILLIO_ACCOUNT_SID, base64EncodedCredentials, smsData).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                hidProgressDialog();
                try {
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        Log.d("TAG", "onResponse->success");
                    } else {
                        String err = response.errorBody().string();
                        Log.d("TAG", "onResponse->failure");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("TAG", "onFailure");
            }
        });

        // Facebook
        Map<String, String> smsDataFacebook = new HashMap<>();
        smsDataFacebook.put("To", "messenger:100011162358622");
        smsDataFacebook.put("From", "messenger:" + FACEBOOK_CHANEL_ID);
        smsDataFacebook.put("Body", messageModel.message);
        if (messageModel.type == MessageModel.TYPE_PHOTO) {
            smsDataFacebook.put("MediaUrl", messageModel.photoFileUrl);
        }
        api.sendMessage(AppConstant.TWILLIO_ACCOUNT_SID, base64EncodedCredentials, smsDataFacebook).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        Log.d("TAG", "onResponse->success");
                    } else {
                        String err = response.errorBody().string();
                        Log.d("TAG", "onResponse->failure");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("TAG", "onFailure");
            }
        });

        // Line
        Map<String, String> smsDataLine = new HashMap<>();
        smsDataLine.put("To", "line:" + otherUser.phoneNumber);
        smsDataLine.put("From", "line:" + LINE_CHANEL_ID);
        smsDataLine.put("Body", messageModel.message);
        if (messageModel.type == MessageModel.TYPE_PHOTO) {
            smsDataLine.put("MediaUrl", messageModel.photoFileUrl);
        }
        api.sendMessage(AppConstant.TWILLIO_ACCOUNT_SID, base64EncodedCredentials, smsDataLine).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.isSuccessful()) {
                        String result = response.body().string();
                        Log.d("TAG", "onResponse->success");
                    } else {
                        String err = response.errorBody().string();
                        Log.d("TAG", "onResponse->failure");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.d("TAG", "onFailure");
            }
        });

        addMessageOnScreen(messageModel);
        AppPreference appPreference = new AppPreference(this);
        ArrayList<MessageModel> allMessages = appPreference.getMessagesData();
        allMessages.add(messageModel);
        appPreference.setMesagesData(allMessages);

        NotificationModel.sendMessageNotification(otherUser, messageModel);
    }

    public void refresh() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                chatLst.removeAllViews();
                AppPreference appPreference = new AppPreference(instance);
                ArrayList<MessageModel> messageModels = appPreference.getMessagesData(otherUser.phoneNumber);
                for (int i = 0; i < messageModels.size(); i++) {
                    addMessageOnScreen(messageModels.get(i));
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fileChooser != null)
            fileChooser.release();
    }

    @Override
    public void onContentSelected(int fileType, Content content) {
        if (fileType == FileType.TYPE_IMAGE) {
            if (sendImageBitmap != null)
                sendImageBitmap.recycle();
            sendImageBitmap = content.getBitmap();

            String filePath = ResourceUtil.getAvatarFilePath();
            ResourceUtil.saveBitmapToSdcard(sendImageBitmap, filePath);
            sendImageBitmap = ResourceUtil.decodeSampledBitmapFromFile(filePath, UserModel.AVATAR_SIZE);

            makeMessage(MessageModel.TYPE_PHOTO);
        } else {
            MessageUtil.showError(this, R.string.choose_image);
        }
    }

    @Override
    public void onError(Error error) {
    }
}
