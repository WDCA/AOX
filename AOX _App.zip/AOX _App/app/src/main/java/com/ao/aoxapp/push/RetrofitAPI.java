/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.push;

import com.ao.aoxapp.model.NotificationModel;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface RetrofitAPI {
    @Headers({"Authorization: key=AAAA1RdDByY:APA91bGlu-437IKLTZZSUEzPXQQ3ejBF93ppKiTyOExdVakINoDGLIYPi6Z91nzEPBnqblGOG1v1hXX4wCvoU32LolX44PMb_PXcoZGfmzI5b1NjwOVp5eWXWfbpe8Y9GM3pAsAoPJ9l",
            "Content-Type:application/json"})
    @POST("fcm/send")
    Call<ResponseBody> sendPushNotification(@Body NotificationModel.RequestNotificaton requestNotificaton);
}
