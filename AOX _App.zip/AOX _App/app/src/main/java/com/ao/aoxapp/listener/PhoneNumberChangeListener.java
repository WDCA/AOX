/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.listener;

public abstract class PhoneNumberChangeListener {
    public abstract void onTextChanged();
}
