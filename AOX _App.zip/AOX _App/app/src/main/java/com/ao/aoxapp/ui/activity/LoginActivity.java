/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.ao.aoxapp.AppPreference.KEY.FCM_TOKEN;

public class LoginActivity extends BaseActivity {
    private static final String TAG = "LoginActivity";

    @BindView(R.id.txt_phoneNumber)
    EditText txt_phoneNumber;

    @BindView(R.id.txt_pass)
    EditText txt_pass;

    private ArrayList<UserModel> userModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        getUsers();
    }

    @Override
    public void onBackPressed() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_layout);
        dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
        TextView title = (TextView) dialog.findViewById(R.id.txt_title);
        TextView message = (TextView) dialog.findViewById(R.id.txt_message);
        TextView left = (TextView) dialog.findViewById(R.id.btn_left);
        TextView right = (TextView) dialog.findViewById(R.id.btn_right);
        title.setText(getResources().getString(R.string.app_name));
        message.setText("Are you sure you want to exit?");
        left.setText("Ok");
        right.setText("Cancel");
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @OnClick(R.id.btn_signin)
    public void onLogin() {
        login();
    }

    @OnClick(R.id.btn_signup)
    public void onSignup() {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
    }

    private void login() {
        if (!DeviceUtil.isNetworkAvailable(this)) {
            return;
        }

        if (!isValid()) {
            return;
        }

        final String phoneNumber = txt_phoneNumber.getText().toString().trim();

        UserModel userModel = UserModel.getUserByPhoneNumber(userModels, phoneNumber);
        if (userModel != null) {
            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(phoneNumber);

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    ref.removeEventListener(this);
                    try {
                        UserModel.currentUser = dataSnapshot.getValue(UserModel.class);
                        DatabaseReference firebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(phoneNumber);
                        firebaseDBReference.child(FirebaseConst.FIELD_USER_TOKEN).setValue(AppPreference.getStr(FCM_TOKEN, ""));
                        UserModel.currentUser.getContacts(dataSnapshot.child(FirebaseConst.FIELD_USER_CONTACTS));

                        gotoMainActivity();
                    } catch (Exception e) {}
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    System.out.println("The read failed: " + databaseError.getCode());
                }
            });
        } else {
            MessageUtil.showError(this, R.string.Credential_not_records);
        }
    }

    private boolean isValid() {
        String strPhoneNumber = txt_phoneNumber.getText().toString();
        if (TextUtils.isEmpty(strPhoneNumber)) {
            MessageUtil.showError(this, getResources().getString(R.string.enter_phonenumber));
            return false;
        }

        return true;
    }

    private void gotoMainActivity() {
        AppPreference.setBool(AppPreference.KEY.SIGN_IN_AUTO, true);
        AppPreference.setStr(AppPreference.KEY.SIGN_IN_USERNAME, txt_phoneNumber.getText().toString().trim());

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
    }

    private void getUsers() {
        if (!DeviceUtil.isNetworkAvailable(this)) {
            return;
        }

        userModels.clear();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER);
        ref.addChildEventListener(mUsersChildEventListener);
    }

    ChildEventListener mUsersChildEventListener = new ChildEventListener() {
        @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                userModels.add(userModel);
            } catch (Exception e) {}
        }
        @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                int index2 = UserModel.getIndexOfItem(userModels, userModel);
                if (index2 >= 0) {
                    userModels.remove(index2);
                    userModels.add(index2, userModel);
                }
            } catch (Exception e) {}
        }
        @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                int index2 = UserModel.getIndexOfItem(userModels, userModel);
                if (index2 >= 0) {
                    userModels.remove(index2);
                }
            } catch (Exception e) {}
        }
        @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
        @Override public void onCancelled(DatabaseError databaseError) {}
    };
}
