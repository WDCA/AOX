/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.push;

import android.app.IntentService;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;

import com.ao.aoxapp.AppPreference;
import com.google.firebase.iid.FirebaseInstanceId;

import static com.ao.aoxapp.AppPreference.KEY.FCM_TOKEN;

public class FirebasePushRegistrationIntentService extends IntentService {
    private static final String TAG = "IntentService";
    private static final String LOGS = "PushRegService";

    public FirebasePushRegistrationIntentService() {
        super("FirebasePushRegistrationIntentService");
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        String token = getFcmToken();
        Log.d(TAG, "FCM_TOKEN : " + token);

        if (!TextUtils.isEmpty(token)) {
            sendTokenToBackend(token);
        }
    }

    @Nullable
    private String getFcmToken() {
        try {
            return FirebaseInstanceId.getInstance().getToken();
        } catch (Exception e) {
            Log.d(LOGS, "Failed to obtain token", e);
        }

        return null;
    }

    private void sendTokenToBackend(String token) {
        AppPreference.setStr(FCM_TOKEN, token);
    }
}
