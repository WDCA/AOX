/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ImageView;

import androidx.core.app.ActivityCompat;

import com.ao.aoxapp.AppPreference;
import com.ao.aoxapp.R;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.ao.aoxapp.utility.PermissionUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.ao.aoxapp.AppPreference.KEY.FCM_TOKEN;
import static com.ao.aoxapp.utility.MessageUtil.TYPE_WARNING;

public class SplashActivity extends BaseActivity {
    public static SplashActivity instance;

    @BindView(R.id.img_icon)
    ImageView img_icon;

    private static final String TAG = "SplashActivity";
    public static boolean isFirst = true;

    public static final int REQUEST_PERMISSION = 1;
    public static String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ButterKnife.bind(this);
        instance = this;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (isFirst) {
            isFirst = false;

            checkPermissions();
        } else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    gotoNextPage();
                }
            }, 1000);
        }
    }

    public void checkPermissions() {
        int permission0 = ActivityCompat.checkSelfPermission(instance, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permission1 = ActivityCompat.checkSelfPermission(instance, Manifest.permission.CAMERA);
        int permission2 = ActivityCompat.checkSelfPermission(instance, Manifest.permission.RECORD_AUDIO);
        int permission3 = ActivityCompat.checkSelfPermission(instance, Manifest.permission.ACCESS_FINE_LOCATION);

        if (permission0 != PackageManager.PERMISSION_GRANTED
            || permission1 != PackageManager.PERMISSION_GRANTED
            || permission2 != PackageManager.PERMISSION_GRANTED
            || permission3 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    instance,
                    PERMISSIONS,
                    REQUEST_PERMISSION
            );
        } else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    gotoNextPage();
                }
            }, 1000);
        }

//        if (!PermissionUtils.checkPermissionForExternalStorage(instance)) {
//            PermissionUtils.requestPermissionForExternalStorage(instance);
//        }
//
//        if (!PermissionUtils.checkPermissionForCamera(instance)) {
//            PermissionUtils.requestPermissionForCamera(instance);
//        }
//
//        if (!PermissionUtils.checkPermissionForRecordAudio(instance)) {
//            PermissionUtils.requestPermissionForRecordAudio(instance);
//        }
//
//        if (!PermissionUtils.checkPermissionForFineLocation(instance)) {
//            PermissionUtils.requestPermissionForFineLocation(instance);
//        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        switch (requestCode)
        {
            case PermissionUtils.EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE:
            case PermissionUtils.CAMERA_PERMISSION_REQUEST_CODE:
            case PermissionUtils.RECORD_AUDIO_PERMISSION_REQUEST_CODE:
            case PermissionUtils.FINE_LOCATION_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    // Permission Granted.
                    Log.d(TAG, "Permission Granted.");
                }
                else
                {
                    // Permission Denied
                    Log.d(TAG, "Permission Denied.");
                }
                break;
        }
    }

    private void gotoNextPage() {
        boolean signedAuto = AppPreference.getBool(AppPreference.KEY.SIGN_IN_AUTO, false);
        final String phoneNumber = AppPreference.getStr(AppPreference.KEY.SIGN_IN_USERNAME, null);
        boolean isNetworkAvailable = DeviceUtil.isNetworkAvailableNoMessage(this);

        if (!signedAuto || TextUtils.isEmpty(phoneNumber)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else if (isNetworkAvailable) {
            showProgressDialog();
            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(phoneNumber);

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    hidProgressDialog();
                    ref.removeEventListener(this);
                    try {
                        UserModel.currentUser = dataSnapshot.getValue(UserModel.class);
                        DatabaseReference firebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(phoneNumber);
                        firebaseDBReference.child(FirebaseConst.FIELD_USER_TOKEN).setValue(AppPreference.getStr(FCM_TOKEN, ""));
                        UserModel.currentUser.getContacts(dataSnapshot.child(FirebaseConst.FIELD_USER_CONTACTS));

                        Intent intent = new Intent(instance, MainActivity.class);
                        startActivity(intent);
                        finish();
                        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
                    } catch (Exception e) {}
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    hidProgressDialog();
                    System.out.println("The read failed: " + databaseError.getCode());
                }
            });
        } else if (!isNetworkAvailable) {
            MessageUtil.showAlertDialog(this, TYPE_WARNING, R.string.msg_error_network, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
        }
    }
}
