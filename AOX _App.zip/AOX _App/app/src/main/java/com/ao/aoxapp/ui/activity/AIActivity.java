/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.ao.aoxapp.R;
import com.bumptech.glide.Glide;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AIActivity extends BaseActivity {
    @BindView(R.id.img_view)
    ImageView img_view;

    private float mFirstX;
    private float mFirstY;
    private boolean goVoice = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai);
        ButterKnife.bind(this);

        Glide.with(this).load(R.drawable.ao).into(img_view);

        img_view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                float lastX = ev.getX();
                float lastY = ev.getY();
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        mFirstX = lastX;
                        mFirstY = lastY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float dx = lastX - mFirstX;
                        float dy = lastY - mFirstY;
                        if (Math.abs(dy) < Math.abs(dx)) {
                            if (dx < 0 && Math.abs(dx) > 3) {
                                gotoVoice();
                            }
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        mFirstX = 0;
                        mFirstY = 0;
                        break;
                }

                return true;
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        goVoice = false;
    }

    @Override
    public void onBackPressed() {
        onBack();
    }

    @OnClick(R.id.btn_back)
    public void onBack() {
        finish();
        overridePendingTransition(R.anim.exit_to_left, R.anim.exit_to_right);
    }

    private void gotoVoice() {
//        if (!goVoice) {
//            goVoice = true;
//            String otherUserPhoneNumber = getIntent().getStringExtra(AppConstant.EK_USER_PHONENUMBER);
//            Intent intent = new Intent(this, VoiceActivity.class);
//            intent.putExtra(AppConstant.EK_USER_PHONENUMBER, otherUserPhoneNumber);
//            startActivity(intent);
//            overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
//        }
    }
}
