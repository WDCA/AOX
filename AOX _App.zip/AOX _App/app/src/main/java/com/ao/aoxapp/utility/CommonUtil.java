/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.utility;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.ao.aoxapp.AOXApp;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

public class CommonUtil {
    /*
	 * Hide keyboard
	 */
    public static void hideKeyboard(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    /*
     * Mail
     */
    // check validation
    public static boolean isValidEmail(String emailAddr) {
        return !TextUtils.isEmpty(emailAddr) && android.util.Patterns.EMAIL_ADDRESS.matcher(emailAddr).matches();
    }
    public static boolean isValidUserName(String username) {
        return username.matches("^[a-zA-Z]{1,99999}$");
    }
    public static boolean isValidCellNumberOrZipcode(String value) {
        return value.matches("^[0-9]{1,9999}$");
    }

    // check include number
    public static boolean isIncludeNumber(String value) {
        return value.matches(".*\\d+.*");
    }

    // check include letter
    public static boolean isIncludeLetter(String value) {
        return value.matches(".*[a-zA-Z]+.*");
    }
    public static boolean isIncludeLowercaseLetter(String value) {
        return value.matches(".*[a-z]+.*");
    }
    public static boolean isIncludeUppercaseLetter(String value) {
        return value.matches(".*[A-Z]+.*");
    }
    public static byte[] readStream(String path) {
        byte[] bytes = null;

        try {
            FileInputStream fis = new FileInputStream(path);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];

            for (int readNum; (readNum = fis.read(b)) != -1; ) {
                bos.write(b, 0, readNum);
            }

            bytes = bos.toByteArray();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return bytes;
    }

    // send email
    public static void SendEmail(Context context, ArrayList<String> to, String subject, String body, String attachment_url) {
        Intent intent = new Intent(Intent.ACTION_SEND);

        if (TextUtils.isEmpty(attachment_url)) {
            intent.setType("message/rfc822");

        } else {
            intent.setType("vnd.android.cursor.dir/email");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + attachment_url));
        }

        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        if (to != null && to.size() > 0) {
            String[] toArr = to.toArray(new String[to.size()]);
            intent.putExtra(Intent.EXTRA_EMAIL, toArr);
        }

        context.startActivity(Intent.createChooser(intent, "Send Information"));
    }
    public static void SendEmail(Context context, String toEmail, String subject, String body, String attachment_url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri data = Uri.parse("mailto:"
                + toEmail
                + "?subject=" + subject + "&body=" + body +"");
        intent.setData(data);
        if (!TextUtils.isEmpty(attachment_url)) {
            Uri photoURI = Uri.fromFile(new File(attachment_url));
            intent.putExtra(Intent.EXTRA_STREAM, photoURI);
        }
        context.startActivity(intent);
    }

    // show web browser
    public static void ShowBrowser(Context context, String url) {
        if (!url.startsWith("http://") && !url.startsWith("https://"))
            url = "http://" + url;
        Intent browserIntent = new Intent();
        browserIntent.setAction(Intent.ACTION_VIEW);
        browserIntent.addCategory(Intent.CATEGORY_BROWSABLE);
        browserIntent.setData(Uri.parse(url));
        context.startActivity(browserIntent);
    }
    // show map
    public static void showMap(Context context, double latitude1, double longitude1){
//        String uri = "http://maps.google.com/maps?f=d&hl=en&saddr="+latitude1+","+longitude1+"&daddr="+latitude2+","+longitude2;
        String uri = "http://maps.google.com/maps?f=d&hl=en&saddr="+latitude1+","+longitude1;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        context.startActivity(Intent.createChooser(intent, "Select an application"));
    }

    /* Launch market */
    public static void launchMarket() {
        Uri uri = Uri.parse("market://details?id=" + AOXApp.getContext().getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            AOXApp.getContext().startActivity(goToMarket);

        } catch (Exception e) {
            // open with browser
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + AOXApp.getContext().getPackageName()));
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            AOXApp.getContext().startActivity(browserIntent);
        }
    }

    // parse file url change
    public static String getCDNUrlFromParseUrl(String path) {
        path = path.replace("https://parse.brainyapps.com:20019", "https://d2zvprcpdficqw.cloudfront.net/process/10019");
        return path;
    }

    // Double To Double
    public static Double D2D(double value) {
        Double result = Double.valueOf((int)(value * 100)) / 100;
        return result;
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }
}
