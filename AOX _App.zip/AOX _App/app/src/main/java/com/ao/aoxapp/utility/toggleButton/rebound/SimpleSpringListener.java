package com.ao.aoxapp.utility.toggleButton.rebound;

public class SimpleSpringListener implements SpringListener {
  @Override
  public void onSpringUpdate(Spring spring) {
  }

  @Override
  public void onSpringAtRest(Spring spring) {
  }

  @Override
  public void onSpringActivate(Spring spring) {
  }

  @Override
  public void onSpringEndStateChange(Spring spring) {
  }
}
