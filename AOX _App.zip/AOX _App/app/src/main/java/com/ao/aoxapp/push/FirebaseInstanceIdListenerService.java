/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.push;

import com.ao.aoxapp.AppPreference;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import static com.ao.aoxapp.AppPreference.KEY.FCM_TOKEN;

public class FirebaseInstanceIdListenerService extends FirebaseInstanceIdService {
    private static final String LOGS = "FirebaseInstan";

    @Override
    public void onTokenRefresh() {
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        sendTokenToBackend(refreshedToken);
    }

    private void sendTokenToBackend(String token) {
        AppPreference.setStr(FCM_TOKEN, token);
    }
}
