/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.ao.aoxapp.R;
import com.ao.aoxapp.model.FirebaseConst;
import com.ao.aoxapp.model.UserModel;
import com.ao.aoxapp.ui.activity.LoginActivity;
import com.ao.aoxapp.ui.activity.MainActivity;
import com.ao.aoxapp.ui.activity.MessageActivity;
import com.ao.aoxapp.utility.CommonUtil;
import com.ao.aoxapp.utility.DeviceUtil;
import com.ao.aoxapp.utility.MessageUtil;
import com.ao.aoxapp.utility.swipelist.adapter.SwipeAdapter;
import com.ao.aoxapp.utility.swipelist.widget.SwipeListView;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ContactsFragment extends Fragment {
    public MainActivity mainActivity;
    private View mView = null;

    @BindView(R.id.listView)
    SwipeListView listView;

    private SwipeAdapter mAdapter;
    private ArrayList<UserModel> contacts = new ArrayList<>();
    private ArrayList<UserModel> userModels = new ArrayList<>();
    private DatabaseReference refContactDatabase;

    public void setMainActivity(MainActivity activity) { mainActivity = activity; }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_contacts, container, false);
        ButterKnife.bind(this, mView);
        mainActivity = (MainActivity) getActivity();
        mAdapter = new SwipeAdapter(mainActivity, listView.getRightViewWidth(), listView, this);
        return mView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mainActivity = MainActivity.instance;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mView == null)
            return;

        init();
    }

    @OnClick(R.id.btn_add)
    public void onAdd() {
        final Dialog dialog = new Dialog(mainActivity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_add_contact);
        dialog.getWindow().getDecorView().setBackgroundResource(android.R.color.transparent);
        final TextView txt_phoneNumber = (TextView) dialog.findViewById(R.id.txt_phoneNumber);
        TextView left = (TextView) dialog.findViewById(R.id.btn_left);
        TextView right = (TextView) dialog.findViewById(R.id.btn_right);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                String phoneNumber = txt_phoneNumber.getText().toString().trim();
                if (DeviceUtil.isNetworkAvailable(mainActivity)) {
                    final UserModel contact = UserModel.getUserByPhoneNumber(userModels, phoneNumber);
                    if (contact != null) {
                        DatabaseReference mFirebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(UserModel.currentUser.phoneNumber).child(FirebaseConst.FIELD_USER_CONTACTS);
                        DatabaseReference ref = mFirebaseDBReference.push();
                        ref.setValue(phoneNumber, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                if (databaseError == null) {
//                                UserModel.currentUser.contactsList.add(contact);
                                    mAdapter.notifyDataSetChanged();
                                } else {
                                    MessageUtil.showError(mainActivity, R.string.msg_error_network);
                                }
                            }
                        });
                    } else {
                        MessageUtil.showError(mainActivity, R.string.enter_correct_phoneNumber);
                    }
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        CommonUtil.hideKeyboard(mainActivity, listView);
                    }
                }, 500);
            }
        });

        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        CommonUtil.hideKeyboard(mainActivity, listView);
                    }
                }, 500);
            }
        });

        dialog.show();
    }

    public void init() {
        if (UserModel.currentUser == null || UserModel.currentUser.phoneNumber == null) {
            Intent intent = new Intent(mainActivity, LoginActivity.class);
            mainActivity.startActivity(intent);
            mainActivity.finish();
            mainActivity.overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
            return;
        }

        getUsers();
        getContacts();

        mAdapter.setData(contacts);
        listView.setAdapter(mAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                UserModel userModel = contacts.get(position);
                MessageActivity.otherUser = userModel;
                Intent intent = new Intent(mainActivity, MessageActivity.class);
                mainActivity.startActivity(intent);
                mainActivity.overridePendingTransition(R.anim.enter_from_right, R.anim.enter_from_left);
            }
        });
    }

    public void refreshListView() {
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mAdapter.notifyDataSetChanged();
            }
        });
    }

    public void deleteContact(UserModel contact, int position) {
        DatabaseReference mFirebaseDBReference = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(UserModel.currentUser.phoneNumber).child(FirebaseConst.FIELD_USER_CONTACTS).child(contact.keyForContact);
        mFirebaseDBReference.removeValue();
        contacts.remove(position);
        mAdapter.notifyDataSetChanged();
    }

    private void getUsers() {
        if (!DeviceUtil.isNetworkAvailable(mainActivity)) {
            return;
        }

        userModels.clear();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER);
        ref.addChildEventListener(mUsersChildEventListener);
    }

    ChildEventListener mUsersChildEventListener = new ChildEventListener() {
        @Override public void onChildAdded(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                if (userModel != null) {
                    if (userModel.phoneNumber != null && UserModel.currentUser.phoneNumber != null) {
                        if (!userModel.phoneNumber.equals(UserModel.currentUser.phoneNumber)) {
                            userModels.add(userModel);
                        }
                    }
                }
            } catch (Exception e) {}
        }
        @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                if (userModel != null) {
                    if (userModel.phoneNumber != null && UserModel.currentUser.phoneNumber != null) {
                        if (!userModel.phoneNumber.equals(UserModel.currentUser.phoneNumber)) {
                            int index2 = UserModel.getIndexOfItem(userModels, userModel);
                            if (index2 >= 0) {
                                userModels.remove(index2);
                                userModels.add(index2, userModel);
                            }

                            index2 = UserModel.getIndexOfItem(contacts, userModel);
                            if (index2 >= 0) {
                                contacts.remove(index2);
                                contacts.add(index2, userModel);
                            }
                        }
                    }
                }
            } catch (Exception e) {}
        }
        @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                if (userModel != null) {
                    if (userModel.phoneNumber != null && UserModel.currentUser.phoneNumber != null) {
                        if (!userModel.phoneNumber.equals(UserModel.currentUser.phoneNumber)) {
                            int index2 = UserModel.getIndexOfItem(userModels, userModel);
                            if (index2 >= 0) {
                                userModels.remove(index2);
                            }

                            index2 = UserModel.getIndexOfItem(contacts, userModel);
                            if (index2 >= 0) {
                                contacts.remove(index2);
                            }
                        }
                    }
                }
            } catch (Exception e) {}
        }
        @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
        @Override public void onCancelled(DatabaseError databaseError) {}
    };

    private void getContacts() {
        if (!DeviceUtil.isNetworkAvailable(mainActivity)) {
            return;
        }

        if (refContactDatabase == null && UserModel.currentUser.phoneNumber != null) {
            contacts.clear();
            refContactDatabase = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(UserModel.currentUser.phoneNumber).child(FirebaseConst.FIELD_USER_CONTACTS);
            refContactDatabase.addChildEventListener(mContactsChildEventListener);
        }
    }

    ChildEventListener mContactsChildEventListener = new ChildEventListener() {
        @Override public void onChildAdded(final DataSnapshot contactDataSnapshot, String s) {
            try {
                String contactPhoneNumber = contactDataSnapshot.getValue(String.class);
                final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child(FirebaseConst.TBL_USER).child(contactPhoneNumber);
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        ref.removeEventListener(this);
                        try {
                            UserModel userModel = dataSnapshot.getValue(UserModel.class);
                            if (userModel != null) {
                                userModel.keyForContact = contactDataSnapshot.getKey();
                                contacts.add(userModel);
                                mAdapter.notifyDataSetChanged();
                            }
                        } catch (Exception e){}
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        System.out.println("The read failed: " + databaseError.getCode());
                    }
                });
            } catch (Exception e) {}
        }
        @Override public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            try {
                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                if (userModel != null) {
                    int index2 = UserModel.getIndexOfItem(contacts, userModel);
                    if (index2 >= 0) {
                        contacts.remove(index2);
                        contacts.add(index2, userModel);
                    }
                    mAdapter.notifyDataSetChanged();
                }
            } catch (Exception e) {}
        }
        @Override public void onChildRemoved(DataSnapshot dataSnapshot) {
            String contactPhoneNumber = dataSnapshot.getValue(String.class);
            for (int i = 0; i < contacts.size(); i++) {
                if (contacts.get(i).phoneNumber != null && contactPhoneNumber != null) {
                    if (contacts.get(i).phoneNumber.equals(contactPhoneNumber)) {
                        contacts.remove(i);
                    }
                    mAdapter.notifyDataSetChanged();
                }
            }
        }
        @Override public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
        @Override public void onCancelled(DatabaseError databaseError) {}
    };
}
