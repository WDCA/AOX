/**
 *
 * AOX App
 * AO
 *
 * Created by TIAN DONG
 * Copyright © 2019 AO. All rights reserved.
 */

package com.ao.aoxapp.ui.activity;

import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ao.aoxapp.AOXApp;
import com.ao.aoxapp.R;
import com.ao.aoxapp.ui.dialog.MyProgressDialog;
import com.ao.aoxapp.utility.PermissionUtils;

public class BaseActivity extends AppCompatActivity {
    private static final String TAG = "BaseActivity";

    public MyProgressDialog dlg_progress;
    public BaseActivity baseActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();

        dlg_progress = new MyProgressDialog(this);

        baseActivity = this;
    }

    @Override
    protected void onResume() {
        super.onResume();
        AOXApp.currentActivity = this;

        PermissionUtils.checkPermissions(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        AOXApp.currentActivity = null;
    }

    @Override
    public void onRestart() {
        super.onRestart();

        if (dlg_progress == null) {
            dlg_progress = new MyProgressDialog(this);
        }
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        if (dlg_progress != null)
            dlg_progress.dismiss();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PermissionUtils.EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(this,
//                            R.string.storage_permissions_granted,
//                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.storage_permissions_granted));
                } else {
                    Toast.makeText(this,
                            R.string.storage_permissions_denied,
                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.storage_permissions_denied));
                }
                break;
            case PermissionUtils.CAMERA_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(this,
//                            R.string.camera_permissions_granted,
//                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.camera_permissions_granted));
                } else {
                    Toast.makeText(this,
                            R.string.camera_permissions_denied,
                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.camera_permissions_denied));
                }
                break;
            case PermissionUtils.RECORD_AUDIO_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(this,
//                            R.string.record_audio_permissions_granted,
//                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.record_audio_permissions_granted));
                } else {
                    Toast.makeText(this,
                            R.string.record_audio_permissions_denied,
                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.record_audio_permissions_denied));
                }
                break;
            case PermissionUtils.FINE_LOCATION_PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Toast.makeText(this,
//                            R.string.location_permissions_granted,
//                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.location_permissions_granted));
                } else {
                    Toast.makeText(this,
                            R.string.location_permissions_denied,
                            Toast.LENGTH_LONG).show();
                    Log.d(TAG, getString(R.string.location_permissions_denied));
                }
                break;
        }
    }

    public void showProgressDialog() {
        dlg_progress.show();
    }

    public void hidProgressDialog() {
        if (dlg_progress != null && dlg_progress.isShowing()) {
            dlg_progress.dismiss();
        }
    }

    public void changeStatusBarColor(int color) {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(color);
        }
    }
}
